create view IMIONA_W as
SELECT imie from wykladowca
/

