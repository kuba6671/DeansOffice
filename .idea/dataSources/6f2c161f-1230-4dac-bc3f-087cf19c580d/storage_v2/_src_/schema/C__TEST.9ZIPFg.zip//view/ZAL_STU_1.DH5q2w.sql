create view ZAL_STU_1 as
SELECT DISTINCT zaliczenie.nr_albumu, nazwisko, zaliczenie.id_przed, nazwa, typ, sr_ocena as ocena
from zaliczenie JOIN(
SELECT nr_albumu as sid, nazwisko, przedmiot.id_przed as pid, nazwa, typ, sr_ocena
from przedmiot JOIN(
SELECT student.nr_albumu, student.nazwisko, pid, sr_ocena
from student JOIN(
SELECT nr_albumu as sid,id_przed as pid, AVG(ocena) as sr_ocena
from zaliczenie group by nr_albumu, id_przed ORDER BY nr_albumu,id_przed)
ON student.nr_albumu = sid)
ON przedmiot.id_przed = pid)
ON zaliczenie.id_przed = pid AND zaliczenie.nr_albumu = sid ORDER BY nr_albumu,id_przed
/

