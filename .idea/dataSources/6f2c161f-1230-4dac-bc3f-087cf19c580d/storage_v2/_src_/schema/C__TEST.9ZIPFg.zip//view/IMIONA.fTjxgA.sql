create view IMIONA as
SELECT imie from student
/

